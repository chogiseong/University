﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _201501967
{
    class health_1
    {
        public float classhealth(float p1)
        {

            float result = p1 * 2; //런닝머신은 분 X 2 정도의 칼로리가 소모됩니다.

            return result;

        }
    }
}
