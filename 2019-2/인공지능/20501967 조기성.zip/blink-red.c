#include "contiki.h"
#include "dev/leds.h"
#include <stdio.h>

PROCESS(blink_process, "LED blink process - GROUP 3");
AUTOSTART_PROCESSES(&blink_process);

PROCESS_THREAD(blink_process, ev, data)
{
	static struct etimer timer;
	PROCESS_BEGIN();

	while(1){
		etimer set(&timer, CLOCK CONF SECOND);
		leds_toggle(LEDS_RED);
	}
	PROCESS_END();
}