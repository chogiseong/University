﻿namespace _201501967
{
    partial class login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.label_experience = new System.Windows.Forms.Label();
            this.checkBox_experience2 = new System.Windows.Forms.CheckBox();
            this.checkBox_experience1 = new System.Windows.Forms.CheckBox();
            this.buttongender = new System.Windows.Forms.Button();
            this.textBox_kg = new System.Windows.Forms.TextBox();
            this.label_kg = new System.Windows.Forms.Label();
            this.radioButton_woman = new System.Windows.Forms.RadioButton();
            this.label_cm = new System.Windows.Forms.Label();
            this.textBox_cm = new System.Windows.Forms.TextBox();
            this.label_sex = new System.Windows.Forms.Label();
            this.label_number = new System.Windows.Forms.Label();
            this.radioButton_man = new System.Windows.Forms.RadioButton();
            this.textBox_number = new System.Windows.Forms.TextBox();
            this.label_main = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.AllowDrop = true;
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.label_experience);
            this.panel3.Controls.Add(this.checkBox_experience2);
            this.panel3.Controls.Add(this.checkBox_experience1);
            this.panel3.Controls.Add(this.buttongender);
            this.panel3.Controls.Add(this.textBox_kg);
            this.panel3.Controls.Add(this.label_kg);
            this.panel3.Controls.Add(this.radioButton_woman);
            this.panel3.Controls.Add(this.label_cm);
            this.panel3.Controls.Add(this.textBox_cm);
            this.panel3.Controls.Add(this.label_sex);
            this.panel3.Controls.Add(this.label_number);
            this.panel3.Controls.Add(this.radioButton_man);
            this.panel3.Controls.Add(this.textBox_number);
            this.panel3.Controls.Add(this.label_main);
            this.panel3.Controls.Add(this.label_name);
            this.panel3.Controls.Add(this.textBox_name);
            this.panel3.Location = new System.Drawing.Point(12, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(229, 332);
            this.panel3.TabIndex = 35;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(113, 292);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 39;
            this.button1.Text = "마치기";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label_experience
            // 
            this.label_experience.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label_experience.Location = new System.Drawing.Point(13, 220);
            this.label_experience.Name = "label_experience";
            this.label_experience.Size = new System.Drawing.Size(175, 24);
            this.label_experience.TabIndex = 38;
            this.label_experience.Text = "헬스케어 서비스를 이용하신적 있으신가요?";
            // 
            // checkBox_experience2
            // 
            this.checkBox_experience2.AutoSize = true;
            this.checkBox_experience2.Location = new System.Drawing.Point(72, 254);
            this.checkBox_experience2.Name = "checkBox_experience2";
            this.checkBox_experience2.Size = new System.Drawing.Size(60, 16);
            this.checkBox_experience2.TabIndex = 37;
            this.checkBox_experience2.Text = "아니오";
            this.checkBox_experience2.UseVisualStyleBackColor = true;
            // 
            // checkBox_experience1
            // 
            this.checkBox_experience1.AutoSize = true;
            this.checkBox_experience1.Location = new System.Drawing.Point(30, 254);
            this.checkBox_experience1.Name = "checkBox_experience1";
            this.checkBox_experience1.Size = new System.Drawing.Size(36, 16);
            this.checkBox_experience1.TabIndex = 36;
            this.checkBox_experience1.Text = "네";
            this.checkBox_experience1.UseVisualStyleBackColor = true;
            // 
            // buttongender
            // 
            this.buttongender.Location = new System.Drawing.Point(32, 292);
            this.buttongender.Name = "buttongender";
            this.buttongender.Size = new System.Drawing.Size(75, 23);
            this.buttongender.TabIndex = 34;
            this.buttongender.Text = "회원가입";
            this.buttongender.UseVisualStyleBackColor = true;
            this.buttongender.Click += new System.EventHandler(this.buttongender_Click);
            // 
            // textBox_kg
            // 
            this.textBox_kg.Location = new System.Drawing.Point(70, 168);
            this.textBox_kg.Name = "textBox_kg";
            this.textBox_kg.Size = new System.Drawing.Size(100, 21);
            this.textBox_kg.TabIndex = 26;
            // 
            // label_kg
            // 
            this.label_kg.AutoSize = true;
            this.label_kg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label_kg.Location = new System.Drawing.Point(13, 171);
            this.label_kg.Name = "label_kg";
            this.label_kg.Size = new System.Drawing.Size(53, 12);
            this.label_kg.TabIndex = 30;
            this.label_kg.Text = "몸무게 : ";
            // 
            // radioButton_woman
            // 
            this.radioButton_woman.AutoSize = true;
            this.radioButton_woman.Location = new System.Drawing.Point(110, 82);
            this.radioButton_woman.Name = "radioButton_woman";
            this.radioButton_woman.Size = new System.Drawing.Size(35, 16);
            this.radioButton_woman.TabIndex = 32;
            this.radioButton_woman.TabStop = true;
            this.radioButton_woman.Text = "여";
            this.radioButton_woman.UseVisualStyleBackColor = true;
            // 
            // label_cm
            // 
            this.label_cm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label_cm.Location = new System.Drawing.Point(23, 143);
            this.label_cm.Name = "label_cm";
            this.label_cm.Size = new System.Drawing.Size(41, 12);
            this.label_cm.TabIndex = 29;
            this.label_cm.Text = "신장 : ";
            // 
            // textBox_cm
            // 
            this.textBox_cm.Location = new System.Drawing.Point(70, 140);
            this.textBox_cm.Name = "textBox_cm";
            this.textBox_cm.Size = new System.Drawing.Size(100, 21);
            this.textBox_cm.TabIndex = 25;
            // 
            // label_sex
            // 
            this.label_sex.AutoSize = true;
            this.label_sex.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label_sex.Location = new System.Drawing.Point(23, 84);
            this.label_sex.Name = "label_sex";
            this.label_sex.Size = new System.Drawing.Size(41, 12);
            this.label_sex.TabIndex = 33;
            this.label_sex.Text = "성별 : ";
            // 
            // label_number
            // 
            this.label_number.AutoSize = true;
            this.label_number.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label_number.Location = new System.Drawing.Point(23, 113);
            this.label_number.Name = "label_number";
            this.label_number.Size = new System.Drawing.Size(41, 12);
            this.label_number.TabIndex = 28;
            this.label_number.Text = "학번 : ";
            // 
            // radioButton_man
            // 
            this.radioButton_man.AutoSize = true;
            this.radioButton_man.Location = new System.Drawing.Point(70, 82);
            this.radioButton_man.Name = "radioButton_man";
            this.radioButton_man.Size = new System.Drawing.Size(35, 16);
            this.radioButton_man.TabIndex = 31;
            this.radioButton_man.TabStop = true;
            this.radioButton_man.Text = "남";
            this.radioButton_man.UseVisualStyleBackColor = true;
            // 
            // textBox_number
            // 
            this.textBox_number.Location = new System.Drawing.Point(70, 110);
            this.textBox_number.Name = "textBox_number";
            this.textBox_number.Size = new System.Drawing.Size(100, 21);
            this.textBox_number.TabIndex = 24;
            // 
            // label_main
            // 
            this.label_main.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label_main.Location = new System.Drawing.Point(13, 10);
            this.label_main.Name = "label_main";
            this.label_main.Size = new System.Drawing.Size(203, 28);
            this.label_main.TabIndex = 22;
            this.label_main.Text = "안녕하세요! 헬스케어서비스 입니다. 자신의 개인정보를 입력해 주세요.";
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label_name.Location = new System.Drawing.Point(24, 52);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(41, 12);
            this.label_name.TabIndex = 27;
            this.label_name.Text = "이름 : ";
            // 
            // textBox_name
            // 
            this.textBox_name.Location = new System.Drawing.Point(71, 49);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(100, 21);
            this.textBox_name.TabIndex = 23;
            this.textBox_name.TextChanged += new System.EventHandler(this.textBox_name_TextChanged);
            // 
            // login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(258, 370);
            this.Controls.Add(this.panel3);
            this.Name = "login";
            this.Text = "회원가입";
            this.Load += new System.EventHandler(this.login_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label_experience;
        private System.Windows.Forms.CheckBox checkBox_experience2;
        private System.Windows.Forms.CheckBox checkBox_experience1;
        private System.Windows.Forms.Button buttongender;
        private System.Windows.Forms.TextBox textBox_kg;
        private System.Windows.Forms.Label label_kg;
        private System.Windows.Forms.RadioButton radioButton_woman;
        private System.Windows.Forms.Label label_cm;
        private System.Windows.Forms.TextBox textBox_cm;
        private System.Windows.Forms.Label label_sex;
        private System.Windows.Forms.Label label_number;
        private System.Windows.Forms.RadioButton radioButton_man;
        private System.Windows.Forms.TextBox textBox_number;
        private System.Windows.Forms.Label label_main;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.TextBox textBox_name;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.Panel panel3;
    }
}